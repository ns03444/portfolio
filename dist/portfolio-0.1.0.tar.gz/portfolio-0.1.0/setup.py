# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['portfolio']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Login>=0.6.2,<0.7.0',
 'Flask-Migrate>=4.0.1,<5.0.0',
 'Flask-WTF>=1.0.1,<2.0.0',
 'Flask>=2.2.2,<3.0.0',
 'WTForms>=3.0.1,<4.0.0',
 'email-validator>=1.3.0,<2.0.0',
 'flask-sqlalchemy>=3.0.2,<4.0.0',
 'gunicorn>=20.1.0,<21.0.0']

setup_kwargs = {
    'name': 'portfolio',
    'version': '0.1.0',
    'description': 'Portfolio - January 2023',
    'long_description': '',
    'author': 'ns03444',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
